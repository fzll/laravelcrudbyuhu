<?php

use Illuminate\Database\Seeder;
use App\Pengguna;

class tabelPengguna extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $pengguna = new Pengguna;
        $pengguna->nama = 'wanita';
        $pengguna->email = 'wanita@gmail.com';
        $pengguna->sandi = 'crewet';
        $pengguna->level = 'user';
        $pengguna->save();
    }
}
