<?php

use Illuminate\Database\Seeder;
use App\Siswa;

class tabelSiswa extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $siswa = new Siswa;
        $siswa->nis = '20.6291';
        $siswa->nama = 'ahmad lutfi muhaimin';
        $siswa->jenis_kelamin = 'laki-laki';
        $siswa->status = '0';
        $siswa->save();
    }
}
