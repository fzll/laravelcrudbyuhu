<?php

use Illuminate\Database\Seeder;
use App\Pengembalian;

class tabelPengembalian extends Seeder

{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // kosongkan data tabel Users
        //DB::table('peminjaman')->delete();
        // buat satu buah data peminjaman
        $pengembalian = new pengembalian;
        $pengembalian->nis = '20.6675';
        $pengembalian->id_pinjam = '96';
        $pengembalian->petugas = 'dewi';
        $pengembalian->keterangan = 'Terlambat 9999 menit';
        $pengembalian->save();
    }
}
