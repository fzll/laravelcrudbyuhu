<?php

use Illuminate\Database\Seeder;
use App\DetailPeminjaman;

class tabelDetailPeminjaman extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $detail_peminjaman = new DetailPeminjaman;
        $detail_peminjaman->id_pinjam = '19';
        $detail_peminjaman->kode = '19';
        $detail_peminjaman->save();
    }
}
