<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        //$this->call('tabelpeminjaman');
        //$this->call('tabelPengembalian');
        //$this->call('tabelDetailPeminjaman');
        $this->call('tabelPengguna');
        //$this->call('tabelSiswa');
        // $this->call('tabelBuku');
    }
}
