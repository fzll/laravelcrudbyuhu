<?php

use Illuminate\Database\Seeder;
use App\peminjaman;

class tabelpeminjaman extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // kosongkan data tabel Users
        //DB::table('peminjaman')->delete();
        // buat satu buah data peminjaman
        $peminjaman = new peminjaman;
        $peminjaman->nis = '20.6271';
        $peminjaman->petugas = 'sinta';
        $peminjaman->save();
    }
}
