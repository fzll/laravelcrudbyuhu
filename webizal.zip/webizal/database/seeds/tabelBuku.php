<?php

use Illuminate\Database\Seeder;
use App\Buku;

class tabelBuku extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $buku = new Buku;
        $buku->kode = '19';
        $buku->judul = 'kassifatus saja`';
        $buku->pengarang = 'imam nawawi jaw';
        $buku->penerbit = 'ml';
        $buku->tahun_terbit = '1543';
        $buku->save();
    }
}
