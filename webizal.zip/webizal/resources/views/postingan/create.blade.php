<?php
//jika mengeklik tombol submit
    //tampilan berhenti 5 detik
    sleep (5);
    //mengambil isi dari filetoupload di tmp_name 
    $_FILES['fileToUpload']['tmp_name'];
    //memindahkan file tadi ke mundur satu/gambar
    move_uploaded_file($_FILES['fileToUpload']['tmp_name'], '../gambar/'.$_FILES['fileToUpload']['name']);
    //memanggil file aduan.php
    include"{{ url('komentar') }}";
?>
<!DOCTYPE html>
<html lang="en">
<head></head>
<body>
	<center>
        <!-- form untuk input file -->
    <form action="" method="post" enctype="multipart/form-data">
    <label for="isi">isi</label> <br>
	<textarea type="text" name="isi"></textarea> <br>
        Masukan Gambar:
        <input onchange="uImage(event)" type="file" name="fileToUpload" id="fileToUpload"><br>
        <input type="submit" value="Adukan" name="submit">
        <br>
</a>
    </form>
</center>
</body>
</html>