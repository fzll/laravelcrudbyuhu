<link rel="stylesheet" href="{{ asset('css/gaya.css') }}">
<div class="kiri">

<ul>
   <li><a href="{{ url('me/about') }}">Tentang Saya</a></li>
   <li><a href="{{ url('komentar') }}">comentar public</a></li>
   <li><a href="{{ url('me/sekolah') }}">Sekolah saya</a></li>
   <li><a href="{{ url('aku') }}">Cerita Tentang saya</a></li>
   <li><a href="{{ url('postingan') }}">foto foto saya</a></li>
</div>