<link rel="stylesheet" href="{{ asset('izal/css/bootstrap.css') }}">
<center><table>
    <th>
        <td><img src="{{ asset('me/b.jpg') }}" alt="" class="logo"></td>
        <td><h1>Muhammad Faizal Romadhon</h1></td>
    </th>
</table>
</center>