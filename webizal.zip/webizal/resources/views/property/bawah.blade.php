<center><table>
    <th>
        <td><img src="{{ asset('me/c.jfif') }}" alt="" class="logo"></td>
        <td><h1><a href="">faizll04</a></h1></td>
        <td><img src="{{ asset('me/e.jfif') }}" alt="" class="logo"></td>
        <td><h1><a href=""></a></h1></td>
        <td><img src="{{ asset('me/d.jfif') }}" alt="" class="logo"></td>
        <td><h1><a href="">nia sania</a></h1></td>
        <td><img src="{{ asset('me/f.jfif') }}" alt="" class="logo"></td>
        <td><h1><a href=""></a></h1></td>
    </th>
</table>
<br><br><br>
</center>