<link rel="stylesheet" href="<?php echo e(asset('izal/css/bootstrap.css')); ?>">
<center><table>
    <th>
        <td><img src="<?php echo e(asset('me/b.jpg')); ?>" alt="" class="logo"></td>
        <td><h1>Muhammad Faizal Romadhon</h1></td>
    </th>
</table>
</center><?php /**PATH D:\xampp\htdocs\webizal\resources\views/property/atas.blade.php ENDPATH**/ ?>