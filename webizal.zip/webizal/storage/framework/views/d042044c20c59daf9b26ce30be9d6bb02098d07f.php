

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>RPL BOS SENGGOL DONG</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('izal/css/bootstrap.css')); ?>">
    <!-- Styles -->
    <style>
        html,
        body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Nunito', sans-serif;
            font-weight: 100;
            margin: 0;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 26px;
        }

        .links>a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
    </style>
</head>

<body>
        <?php if(Route::has('login')): ?>
        <div class="top-right links">
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(url('/home')); ?>">Home</a>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>">Login</a>

            <?php if(Route::has('register')): ?>
            <a href="<?php echo e(route('register')); ?>">Register</a>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <h1>
        <?php echo $__env->make('property/atas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('property/kanan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </h1>
        <div class="content">
            <div class="title m-b-md">
                <div class="kiri">

<ul>
   <li><img src="<?php echo e(asset('me/a.jpg')); ?>" width="70px"></li>

</div class="kanan">
        Hai perkenalkan nama saya Muhammad Faizal Romadhon <br>
        saya berasal dari <a href="https://rimpak-sapuran.wonosobokab.go.id/">Rimpak,sapuran,Wonosobo</a><br>
        usia <br>
        dan saya adalah anak pertama <br>
        ya sebagai anak pertama saya harus memberikan contoh yang baik untuk adik adik saya
            <br><br>
        kata kata bozz <br>
        jika anda berada dalam suatu kesulitan maka itu masalah anda bukan masalah saya,saya tidak akan ikut campur masalah anda
        <br><br>
        lagu favorit saya adalah <a href="https://www.youtube.com/watch?v=QJO3ROT-A4E">makes you beautiful-one direction</a>
        </div>
        </div>
        <?php echo $__env->make('property/bawah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH D:\xampp\htdocs\webizal\resources\views/me/about.blade.php ENDPATH**/ ?>