<link rel="stylesheet" href="<?php echo e(asset('css/gaya.css')); ?>">
<div class="kiri">

<ul>
   <li><a href="<?php echo e(url('me/about')); ?>">Tentang Saya</a></li>
   <li><a href="<?php echo e(url('komentar')); ?>">comentar public</a></li>
   <li><a href="<?php echo e(url('me/sekolah')); ?>">Sekolah saya</a></li>
   <li><a href="<?php echo e(url('aku')); ?>">Cerita Tentang saya</a></li>
   <li><a href="<?php echo e(url('postingan')); ?>">foto foto saya</a></li>
</div><?php /**PATH D:\xampp\htdocs\webizal\resources\views/property/kanan.blade.php ENDPATH**/ ?>