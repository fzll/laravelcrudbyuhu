

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>RPL BOS SENGGOL DONG</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Styles -->
    <style>
        html,
        body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Nunito', sans-serif;
            font-weight: 100;
            margin: 0;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 26px;
        }

        .links>a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
    </style>
</head>

<body>
        <?php if(Route::has('login')): ?>
        <div class="top-right links">
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(url('/home')); ?>">Home</a>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>">Login</a>

            <?php if(Route::has('register')): ?>
            <a href="<?php echo e(route('register')); ?>">Register</a>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <h1>
        <?php echo $__env->make('property/atas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('property/kanan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </h1>
        <div class="content">
            <div class="title m-b-md">
                <div class="kiri">

<ul>
   <li><img src="<?php echo e(asset('me/a.jpg')); ?>" width="70px"></li>

</div class="kanan">
        Cerita tentang saya <br>
        saya adalah anak pertama dari 2 bersaudara. ya sebagai anak pertama saya harus memberikan contoh denggan adik adik saya. saya mulai cerita penggalaman saya 
        dari waktu sd saya saat sd saya masih menjadi anak yang polos sering mengaji karena kepaksa dan pada suatu saat saya terkena musibah yaitu bada saat gempa jogja
        pada saat itu rumah saya ambruk karena itu akhirnya saya pindah kerumah saudara saya setelah beberapa waktu saya kehilangan seorang kakek yang sanggat baik terhadap saya
        setelah 8 hari saya dan keluarga saya pergi merantau ke kalimantan dan akhirnya saya tidak betah disana setelah 6 bulan akhirnya saya pun kembali ke rumah kakek dari ibu saya 
        kemudian saya kembali sekolah di sd 2 warangan dan saya sekolah disitu sampai kelas 3sd dan akhirnya sayapun pindah kE daerah asal saya yaitu di rimpak,sapuran wonosobo
        dan saya sekolah disitu sampai lulus akhirnya saya lulus denggan peringkat 10 dari 30 siswa
        pengalaman yang tidak pernah saya lupakan adalah pada saat saya kelas 6 sd teman saya ada yang meninggal karena gantung diri
        saya tidak tahu karena apa ia gantung diri sebab saya adalah teman terbaik dari anak itu
        
        </div>
        <?php echo $__env->make('property/bawah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH D:\xampp\htdocs\webizal\resources\views/me/cerita.blade.php ENDPATH**/ ?>