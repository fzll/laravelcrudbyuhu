<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('rpl3', function () {
    return 'RPL 3 SELALU CODING DENGGAN MUMET BAHAGIA
    <br> <a href ="https://rpl.smktaq-wsb.sch.id/profil/tim-rpl">
    ini halaman guru RPL</a>';
});
Route::get('rpl/{jenis?}', function ($jenis = null) {
    if ($jenis == null) return 'RPL 3 SELALU CODING DENGGAN MUMET BAHAGIA
    <br> <a href ="https://rpl.smktaq-wsb.sch.id/profil/tim-rpl">
    ini halaman guru RPL</a>';
    return ' <br><br><br><br><br><br><br><center><h2>RPL Bersama 
     ' . $jenis . ' SELALU CODING DENGGAN MUMET BAHAGIA
    <br> <a href ="https://rpl.smktaq-wsb.sch.id/profil/tim-rpl ">
    ini halaman guru RPL</a>
    <br> <a href ="http://izalezpz.epizy.com/login.php">
    ini halaman saya</a></h2>
    ';
});
Route::get('/', function () {
    return view('me/profil');
});
Route::get('me/sekolah', function () {
    return view('me/sekolah');
});
Route::get('me/about', function () {
    return view('me/about');
});
Route::resource('komentar',komentarcontroller::class);
// Route::resource('postingan',postingancontroller::class);
Route::get('postingan', function () {
    return view('me/foto');
});
Route::get('aku', function () {
    return view('me/cerita');
});