-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2022 at 03:30 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `latihan_6223`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `kode` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `judul` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pengarang` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `penerbit` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tahun_terbit` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`kode`, `judul`, `pengarang`, `penerbit`, `tahun_terbit`, `created_at`, `updated_at`) VALUES
('1', 'the have', 'izal', 'suhu', '2004', '2022-11-03 19:16:18', '2022-11-03 19:16:18'),
('10', 'al jabar', 'al-khuarizmi', 'wong arab', '1978', '2022-11-03 19:24:04', '2022-11-03 19:24:04'),
('11', 'biologi', 'al-khuarizmi', 'wong arab', '1978', '2022-11-03 19:24:28', '2022-11-03 19:24:28'),
('12', 'perbintangan', 'al-khuarizmi', 'wong arab', '1978', '2022-11-03 19:24:45', '2022-11-03 19:24:45'),
('13', 'algoritma', 'al-khuarizmi', 'wong arab', '1978', '2022-11-03 19:25:01', '2022-11-03 19:25:01'),
('14', 'pemograman', 'al-khuarizmi', 'wong arab', '1978', '2022-11-03 19:25:32', '2022-11-03 19:25:32'),
('15', 'komputerisasi', 'al-khuarizmi', 'wong arab', '1978', '2022-11-03 19:25:56', '2022-11-03 19:25:56'),
('16', 'nahwu', 'as son haji', 'wong arab', '778', '2022-11-03 19:27:14', '2022-11-03 19:27:14'),
('17', 'cara menggunakan of laner', 'bang jez', 'ml crew', '2022', '2022-11-03 19:28:21', '2022-11-03 19:28:21'),
('18', 'mancaser united', 'ten haq', 'ucl', '2022', '2022-11-03 19:29:04', '2022-11-03 19:29:04'),
('19', 'kassifatus saja`', 'imam nawawi jaw', 'ml', '1543', '2022-11-03 19:34:10', '2022-11-03 19:34:10'),
('2', 'the php', 'prov_izal', 'albert', '2000', '2022-11-03 19:17:18', '2022-11-03 19:17:18'),
('20', 'tutor ling', 'ahwaz', 'ml', '2022', '2022-11-03 19:32:15', '2022-11-03 19:32:15'),
('3', 'the coding', 'prov_izal', 'aziz', '2000', '2022-11-03 19:17:45', '2022-11-03 19:17:45'),
('4', 'the html', 'prov_izal', 'aziz', '2005', '2022-11-03 19:19:39', '2022-11-03 19:19:39'),
('5', 'the java', 'prov_izal', 'aziz', '2005', '2022-11-03 19:20:40', '2022-11-03 19:20:40'),
('6', 'the iphone', 'prov_izal', 'aziz', '2005', '2022-11-03 19:21:04', '2022-11-03 19:21:04'),
('7', 'the simpone', 'prov_izal', 'aziz', '2005', '2022-11-03 19:21:19', '2022-11-03 19:21:19'),
('8', 'the takhasus', 'prov_izal', 'aziz', '2005', '2022-11-03 19:22:08', '2022-11-03 19:22:08'),
('9', 'sejarah nabi', 'al-khuarizmi', 'wong arab', '1978', '2022-11-03 19:23:40', '2022-11-03 19:23:40');

-- --------------------------------------------------------

--
-- Table structure for table `detail_peminjaman`
--

CREATE TABLE `detail_peminjaman` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_pinjam` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `detail_peminjaman`
--

INSERT INTO `detail_peminjaman` (`id`, `id_pinjam`, `kode`, `created_at`, `updated_at`) VALUES
(1, '3', '5', '2022-11-03 18:58:49', '2022-11-03 18:58:49'),
(2, '1', '1', '2022-11-03 20:12:18', '2022-11-03 20:12:18'),
(3, '2', '2', '2022-11-03 20:12:29', '2022-11-03 20:12:29'),
(4, '3', '3', '2022-11-03 20:12:39', '2022-11-03 20:12:39'),
(5, '4', '4', '2022-11-03 20:12:48', '2022-11-03 20:12:48'),
(6, '5', '5', '2022-11-03 20:12:58', '2022-11-03 20:12:58'),
(7, '6', '6', '2022-11-03 20:13:07', '2022-11-03 20:13:07'),
(8, '7', '7', '2022-11-03 20:13:16', '2022-11-03 20:13:16'),
(9, '8', '8', '2022-11-03 20:13:25', '2022-11-03 20:13:25'),
(10, '9', '9', '2022-11-03 20:13:32', '2022-11-03 20:13:32'),
(11, '10', '10', '2022-11-03 20:13:41', '2022-11-03 20:13:41'),
(12, '11', '11', '2022-11-03 20:13:55', '2022-11-03 20:13:55'),
(13, '12', '12', '2022-11-03 20:14:14', '2022-11-03 20:14:14'),
(14, '13', '13', '2022-11-03 20:14:28', '2022-11-03 20:14:28'),
(15, '14', '14', '2022-11-03 20:14:38', '2022-11-03 20:14:38'),
(16, '15', '15', '2022-11-03 20:14:48', '2022-11-03 20:14:48'),
(17, '16', '16', '2022-11-03 20:14:59', '2022-11-03 20:14:59'),
(18, '17', '17', '2022-11-03 20:15:08', '2022-11-03 20:15:08'),
(19, '18', '18', '2022-11-03 20:15:18', '2022-11-03 20:15:18'),
(20, '19', '19', '2022-11-03 20:15:27', '2022-11-03 20:15:27');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2022_10_31_033619_create_peminjaman', 1),
(3, '2022_10_31_033714_create_pengembalian', 1),
(7, '2022_10_31_033649_create_detail_peminjaman', 2),
(8, '2022_10_31_033733_create_pengguna', 2),
(9, '2022_10_31_033759_create_buku', 2),
(10, '2022_10_31_033823_create_siswa', 2);

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman`
--

CREATE TABLE `peminjaman` (
  `id_pinjam` bigint(20) UNSIGNED NOT NULL,
  `nis` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `petugas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `peminjaman`
--

INSERT INTO `peminjaman` (`id_pinjam`, `nis`, `petugas`, `created_at`, `updated_at`) VALUES
(1, '20.6223', 'izal', '2022-11-03', '2022-11-03'),
(2, '20.6222', 'aufa', '2022-11-03', '2022-11-03'),
(3, '20.6145', 'tasya', '2022-11-03', '2022-11-03'),
(4, '20.6145', 'aufa', '2022-11-03', '2022-11-03'),
(5, '20.1111', 'izal', '2022-11-03', '2022-11-03'),
(6, '20.1234', 'ahway', '2022-11-03', '2022-11-03'),
(7, '20.7866', 'izal', '2022-11-03', '2022-11-03'),
(8, '20.1223', 'aufa', '2022-11-03', '2022-11-03'),
(9, '20.6223', 'mbak cantik', '2022-11-03', '2022-11-03'),
(10, '20.6254', 'ivan', '2022-11-03', '2022-11-03'),
(11, '20.6249', 'siapa ya', '2022-11-03', '2022-11-03'),
(12, '20.6249', 'siapa ya', '2022-11-03', '2022-11-03'),
(13, '20.6241', 'aufa', '2022-11-03', '2022-11-03'),
(14, '20.6241', 'aufa', '2022-11-03', '2022-11-03'),
(15, '20.8672', 'suhu', '2022-11-03', '2022-11-03'),
(16, '20.5676', 'aziz', '2022-11-03', '2022-11-03'),
(17, '20.5896', 'faqih', '2022-11-03', '2022-11-03'),
(18, '20.6231', 'putri', '2022-11-03', '2022-11-03'),
(19, '20.6291', 'ayu', '2022-11-03', '2022-11-03'),
(20, '20.6271', 'sinta', '2022-11-03', '2022-11-03');

-- --------------------------------------------------------

--
-- Table structure for table `pengembalian`
--

CREATE TABLE `pengembalian` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nis` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_pinjam` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `petugas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pengembalian`
--

INSERT INTO `pengembalian` (`id`, `nis`, `id_pinjam`, `petugas`, `keterangan`, `created_at`, `updated_at`) VALUES
(1, '20.6271', '20', 'sinta', 'Rusak', '2022-11-02 21:30:08', '2022-11-02 21:30:08'),
(2, '20.6223', '1', 'sinta', 'Tepat Waktu', '2022-11-02 21:33:15', '2022-11-02 21:33:15'),
(3, '20.6222', '2', 'ayu', 'Terbakar', '2022-11-02 21:33:54', '2022-11-02 21:33:54'),
(4, '20.6222', '3', 'bla\r\n', 'Dimakan rayap', '2022-11-02 21:35:27', '2022-11-02 21:35:27'),
(5, '20.6145', '3', 'bla', 'Halaman kurang', '2022-11-02 21:36:25', '2022-11-02 21:36:25'),
(6, '20.6111', '4', 'izal', 'tepat waktu', '2022-11-02 21:37:15', '2022-11-02 21:37:15'),
(7, '20.1234', '5', 'izal', 'tepat waktu', '2022-11-02 21:37:43', '2022-11-02 21:37:43'),
(8, '20.7866', '6', 'izal', 'Terlambat', '2022-11-02 21:38:33', '2022-11-02 21:38:33'),
(9, '20.7866', '7', 'izal', 'Terlambat', '2022-11-02 21:39:09', '2022-11-02 21:39:09'),
(10, '20.1223', '7', 'ayu', 'Rusak', '2022-11-02 21:39:45', '2022-11-02 21:39:45'),
(11, '20.1823', '78', 'Mbak Cantik', 'Ada Kecoaknya', '2022-11-02 21:40:50', '2022-11-02 21:40:50'),
(12, '20.1823', '78', 'Mbak Cantik', 'Ada Kecoaknya', '2022-11-02 21:41:41', '2022-11-02 21:41:41'),
(13, '20.1323', '906', 'izal', 'Tepat Waktu', '2022-11-02 21:42:51', '2022-11-02 21:42:51'),
(14, '20.1981', '11', 'izal', 'Tepat Waktu', '2022-11-02 21:43:16', '2022-11-02 21:43:16'),
(15, '20.6245', '11', 'izal', 'Tepat Waktu', '2022-11-02 21:43:30', '2022-11-02 21:43:30'),
(16, '20.6245', '11', 'izal', 'Tepat Waktu', '2022-11-02 21:44:02', '2022-11-02 21:44:02'),
(17, '20.6245', '94', 'izal', 'Terlambat 1 detik', '2022-11-02 21:44:43', '2022-11-02 21:44:43'),
(18, '20.6245', '94', 'izal', 'Terlambat 1 detik', '2022-11-02 21:45:11', '2022-11-02 21:45:11'),
(19, '20.6185', '56', 'izal', 'Terlambat 99 menit', '2022-11-02 21:45:44', '2022-11-02 21:45:44'),
(20, '20.6675', '96', 'dewi', 'Terlambat 9999 menit', '2022-11-02 21:46:10', '2022-11-02 21:46:10'),
(21, '20.6675', '96', 'dewi', 'Terlambat 9999 menit', '2022-11-03 18:54:55', '2022-11-03 18:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `nama` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sandi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`nama`, `email`, `sandi`, `level`, `created_at`, `updated_at`) VALUES
('adminsuhu', 'adminutama@gmail.com', 'adminutama', 'admin', '2022-11-03 20:24:09', '2022-11-03 20:24:09'),
('aufa', 'aufa@gmail.com', 't@5y4', 'karyawan', '2022-11-03 20:17:36', '2022-11-03 20:17:36'),
('budi', 'budi@gmail.com', '123456', 'karyawan', '2022-11-03 20:18:09', '2022-11-03 20:18:09'),
('carlos', 'carlos@gmail.com', 'ucl', 'karyawan', '2022-11-03 20:18:32', '2022-11-03 20:18:32'),
('diva', 'diva@gmail.com', 'aku', 'karyawan', '2022-11-03 20:19:15', '2022-11-03 20:19:15'),
('ela', 'ela@gmail.com', 'rimpak', 'karyawan', '2022-11-03 20:19:33', '2022-11-03 20:19:33'),
('fatan', 'fatan@gmail.com', 'kokiso', 'user', '2022-11-03 20:19:55', '2022-11-03 20:19:55'),
('haryanto', 'haryanto@gmail.com', 'yanto', 'user', '2022-11-03 20:20:26', '2022-11-03 20:20:26'),
('izal', 'izal@gmail.com', 'sidia', 'admin', '2022-11-03 19:03:26', '2022-11-03 19:03:26'),
('jamal', 'jamal@gmail.com', 'abdul', 'user', '2022-11-03 20:20:51', '2022-11-03 20:20:51'),
('luluk', 'luluk@gmail.com', 'kahi', 'user', '2022-11-03 20:21:14', '2022-11-03 20:21:14'),
('makmun', 'king@gmail.com', 'imtheking', 'user', '2022-11-03 20:21:38', '2022-11-03 20:21:38'),
('nafa', 'nava@gmail.com', 'biasa', 'user', '2022-11-03 20:21:53', '2022-11-03 20:21:53'),
('oga', 'oga@gmail.com', 'oke', 'user', '2022-11-03 20:22:16', '2022-11-03 20:22:16'),
('ponisa', 'ponisa@gmail.com', 'poni', 'user', '2022-11-03 20:23:16', '2022-11-03 20:23:16'),
('radit', 'radit@gmail.com', 'radi', 'user', '2022-11-03 20:23:36', '2022-11-03 20:23:36'),
('topik', 'topik@gmail.com', 'tapo', 'user', '2022-11-03 20:24:46', '2022-11-03 20:24:46'),
('ulfa', 'ulfa@gmail.com', 'user', 'user', '2022-11-03 20:25:23', '2022-11-03 20:25:23'),
('vida', 'vida@gmail.com', 'aing', 'user', '2022-11-03 20:25:44', '2022-11-03 20:25:44'),
('wanita', 'wanita@gmail.com', 'crewet', 'user', '2022-11-03 20:26:03', '2022-11-03 20:26:03');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `nis` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_kelamin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`nis`, `nama`, `jenis_kelamin`, `status`, `created_at`, `updated_at`) VALUES
('20.6205', 'irsyad', 'laki-laki', 1, '2022-11-03 19:38:19', '2022-11-03 19:38:19'),
('20.6206', 'rezal', 'laki-laki', 1, '2022-11-03 19:38:53', '2022-11-03 19:38:53'),
('20.6213', 'fiki', 'laki-laki', 1, '2022-11-03 19:39:23', '2022-11-03 19:39:23'),
('20.6221', 'akmal', 'laki-laki', 1, '2022-11-03 19:39:46', '2022-11-03 19:39:46'),
('20.6222', 'aufa', 'laki-laki', 1, '2022-11-03 19:36:10', '2022-11-03 19:36:10'),
('20.6223', 'izal', 'laki-laki', 9, '2022-11-03 19:07:12', '2022-11-03 19:07:12'),
('20.6229', 'faqih', 'laki-laki', 1, '2022-11-03 19:54:58', '2022-11-03 19:54:58'),
('20.6236', 'ivan', 'laki-laki', 1, '2022-11-03 19:37:54', '2022-11-03 19:37:54'),
('20.6278', 'mong', 'laki-laki', 1, '2022-11-03 20:02:48', '2022-11-03 20:02:48'),
('20.6279', 'king makmun', 'laki-laki', 1, '2022-11-03 20:03:20', '2022-11-03 20:03:20'),
('20.6280', 'king makmun', 'laki-laki', 1, '2022-11-03 20:03:43', '2022-11-03 20:03:43'),
('20.6281', 'alisya', 'Perempuan', 1, '2022-11-03 20:04:09', '2022-11-03 20:04:09'),
('20.6282', 'amanda', 'Perempuan', 1, '2022-11-03 20:04:28', '2022-11-03 20:04:28'),
('20.6283', 'bella', 'Perempuan', 1, '2022-11-03 20:04:45', '2022-11-03 20:04:45'),
('20.6284', 'cantika', 'Perempuan', 1, '2022-11-03 20:05:08', '2022-11-03 20:05:08'),
('20.6285', 'diva', 'Perempuan', 1, '2022-11-03 20:05:40', '2022-11-03 20:05:40'),
('20.6286', 'ela', 'Perempuan', 1, '2022-11-03 20:05:52', '2022-11-03 20:05:52'),
('20.6288', 'vida', 'Perempuan', 1, '2022-11-03 20:06:55', '2022-11-03 20:06:55'),
('20.6289', 'wiwin', 'Perempuan', 1, '2022-11-03 20:07:49', '2022-11-03 20:07:49'),
('20.6290', 'zulehah', 'Perempuan', 1, '2022-11-03 20:08:09', '2022-11-03 20:08:09'),
('20.6291', 'ahmad lutfi muhaimin', 'laki-laki', 0, '2022-11-03 20:08:42', '2022-11-03 20:08:42'),
('20.6374', 'aziz', 'laki-laki', 1, '2022-11-03 19:35:08', '2022-11-03 19:35:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`kode`);

--
-- Indexes for table `detail_peminjaman`
--
ALTER TABLE `detail_peminjaman`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`id_pinjam`);

--
-- Indexes for table `pengembalian`
--
ALTER TABLE `pengembalian`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`nama`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`nis`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `detail_peminjaman`
--
ALTER TABLE `detail_peminjaman`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `id_pinjam` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `pengembalian`
--
ALTER TABLE `pengembalian`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
